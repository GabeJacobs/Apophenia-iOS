export LANG=${LANG:-en_US.UTF-8}
export GEM_PATH="$HOME/vendor/bundle/ruby/2.6.0:$GEM_PATH"
export PATH="$HOME/bin:$HOME/bin:$HOME/vendor/bundle/bin:$HOME/vendor/bundle/ruby/2.6.0/bin:$PATH"
export MALLOC_ARENA_MAX=${MALLOC_ARENA_MAX:-2}
export RACK_ENV=${RACK_ENV:-production}
